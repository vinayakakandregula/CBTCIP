document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("event-modal");
    const btn = document.getElementById("save-event-btn");
    const span = document.getElementsByClassName("close-btn")[0];
    const form = document.getElementById("event-form");

    btn.onclick = function () {
        modal.style.display = "block";
    }

    span.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        const eventName = document.getElementById("eventName").value;
        const eventDate = document.getElementById("eventDate").value;
        const eventVenue = document.getElementById("eventVenue").value;

      
        fetch('http://localhost:8080/saveEvent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                eventName: eventName,
                eventDate: eventDate,
                eventVenue: eventVenue
            })
        }).then(response => response.json())
            .then(data => {
                alert('Event saved!');
                modal.style.display = "none";
            }).catch(error => {
                console.error('Error:', error);
                alert('Failed to save event');
            });
    });

    const userId = 'exampleUserId'; 
    fetch(`/api/users/${userId}/events`)
        .then(response => response.json())
        .then(data => {
            const eventsList = document.getElementById('events-list');
            data.forEach(event => {
                const eventCard = document.createElement('div');
                eventCard.className = 'event-card';
                eventCard.innerHTML = ` 
                    <h3>${event.eventName}</h3>
                    <p>Date: ${new Date(event.eventDate).toLocaleDateString()}</p>
                    <p>Venue: ${event.eventVenue}</p>
                    <a href="#">View Details</a>
                `;
                eventsList.appendChild(eventCard);
            });
        }).catch(error => {
            console.error('Error:', error);
            const eventsList = document.getElementById('events-list');
            eventsList.innerHTML = '<p>Failed to load events.</p>';
        });
});
