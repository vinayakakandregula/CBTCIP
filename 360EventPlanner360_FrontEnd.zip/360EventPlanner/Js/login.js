console.log("hello");

let login = document.getElementById("login");




login.addEventListener("click", async (e) => {
    e.preventDefault();
    let email = document.getElementById("name").value;
    let password = document.getElementById("password").value;
    if (email != '' && password != '') {
        try {
            let res = await fetch(`http://localhost:8080/loginuser?email=${email}&password=${password}`, {
                method: "GET",
                headers: {
                    "Content-Type": "Application/json"
                }
            })
            let x = await res.json();
            console.log(res.status);
            if (x.status == 302) {
                window.localStorage.setItem("userid", x.data.id)
                window.location.href = "http://127.0.0.1:5500/Html/user.html";
            } else {
                window.alert(x.message + "😒😒😒");
            }
        } catch (error) {

        }
    } else {
        alert("Please fill all required details...")
    }
   
})

let forgot = document.getElementById("forgot-password")

forgot.addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "forgotpwduser.html"
})