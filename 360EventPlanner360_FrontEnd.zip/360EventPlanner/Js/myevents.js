function logout() {
    localStorage.clear();
    window.location.href = "index.html";
}

document.addEventListener("DOMContentLoaded", function () {
    const userId = localStorage.getItem("userid");
    const eventsListContainer = document.querySelector('.events-list');

    async function fetchEvents() {
        let res = await fetch(`http://localhost:8080/fetchAllEventByUserId?id=${userId}`, {
            method: "GET",
            headers: {
                "Content-Type": "Application/json"
            }
        });
        let x = await res.json();
        console.log(res.status);
        if (res.status == 202) {
            console.log(x.data);
            displayEvents(x.data);
        } else {
            window.alert(x.message + "😒😒😒");
        }
    }

    function displayEvents(events) {
        eventsListContainer.innerHTML = '';
        events.forEach(event => {
            const eventCard = document.createElement('div');
            eventCard.classList.add('event-card');
            eventCard.innerHTML = `
            <div class="event-content" style=text-align:start>
                <h3>Event Name: ${event.eventName}</h3>
                <p>Description: ${event.description}</p>
                <p>Date: ${event.eventDate}</p>
                <p>Venue: ${event.venue}</p>
                <p>Type: ${event.eventType}</p>
                <h4>Guests:</h4>
                <ul>
                    ${event.guests.map(guest => `<li>Name: ${guest.name}<br>Email: ${guest.email}<br>Phone: ${guest.phoneNumber}</li>`).join('')}
                </ul>
                <h4>Budget Items:</h4>
                <ul>
                    ${event.budgetItems.map(item => `<li>${item.item}: $${item.amount}</li>`).join('')}
                </ul>
                <h4>Vendors:</h4>
                <ul>
                    ${event.vendors.map(vendor => `<li>${vendor.name}<br>(${vendor.service}):<br>$${vendor.cost},<br>Contact: ${vendor.contactInfo}</li>`).join('')}
                </ul>
                <button class="update-button" onclick="updateEvent(${JSON.stringify(event).replace(/"/g, '&quot;')})">Update Event</button>
                <button style="background-color:red" class="update-button" onclick="deleteEvent('${event.id}')">Delete Event</button>
            </div>
            `;
            eventsListContainer.appendChild(eventCard);
        });
    }

    window.updateEvent = function (event) {
        localStorage.setItem("event", JSON.stringify(event));
        console.log("Update event:", event);
        window.location.href = "updateevent.html"
    };

    window.deleteEvent = async function (id) {
        let res = await fetch(`http://localhost:8080/deleteEvent?id=${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "Application/json"
            }
        });
        let x = await res.json();
        console.log(res.status);
        if (res.status == 202) {
            window.location.reload();
        } else {
            window.alert(x.message + "😒😒😒");
        }
    };

    // Fetch and display events when the page loads
    fetchEvents();
});
