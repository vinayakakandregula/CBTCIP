console.log("hello");
document.getElementById("eventForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    let eventName = document.getElementById("eventName").value;
    let description = document.getElementById("description").value;
    let venue = document.getElementById("venue").value;
    let eventDate = document.getElementById("eventDate").value;
    // let startTime = document.getElementById("startTime").value;
    // let endTime = document.getElementById("endTime").value;
    let eventType = document.getElementById("eventType").value;

    let guests = [];
    document.querySelectorAll("#guestList .guest").forEach(guestDiv => {
        let name = guestDiv.querySelector(".guestName").value;
        let email = guestDiv.querySelector(".guestEmail").value;
        let phoneNumber = guestDiv.querySelector(".guestPhone").value;
        guests.push({ name, email, phoneNumber });
    });

    let budgetItems = [];
    document.querySelectorAll("#budgetList .budgetItem").forEach(budgetDiv => {
        let item = budgetDiv.querySelector(".budgetItemName").value;
        let amount = budgetDiv.querySelector(".budgetAmount").value;
        budgetItems.push({ item, amount });
    });

    let vendors = [];
    document.querySelectorAll("#vendorList .vendor").forEach(vendorDiv => {
        let name = vendorDiv.querySelector(".vendorName").value;
        let service = vendorDiv.querySelector(".vendorService").value;
        let cost = vendorDiv.querySelector(".vendorCost").value;
        let contactInfo = vendorDiv.querySelector(".vendorContact").value;
        vendors.push({ name, service, cost, contactInfo });
    });

    let organizer = {};
    let userId = localStorage.getItem("userid");

    try {
        let userResponse = await fetch(`http://localhost:8080/fetchuserbyid?id=${userId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
            }
        });

        if (!userResponse.ok) {
            throw new Error("Failed to fetch user data");
        }

        let userResult = await userResponse.json();
        user = userResult.data;

        let eventData = {
            eventName,
            description,
            venue,
            eventDate,
            // startTime,
            // endTime,
            eventType,
            organizer,
            guests,
            budgetItems,
            vendors
        };

        let res = await fetch(`http://localhost:8080/saveEvent?userid=${userId}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(eventData)
        });

        let response = await res.json();
        console.log(user);
        console.log(response.status);
        if (response.status === 201) {
            alert("Event saved successfully!");
            window.location.href = "myevents.html";  // Redirect to events page or another desired page
        } else {
            alert(response.message || "Error saving event");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Failed to save event");
    }
});

function addGuest() {
    const guestList = document.getElementById('guestList');
    const guestDiv = document.createElement('div');
    guestDiv.classList.add('guest');

    guestDiv.innerHTML = `
        <label for="guestName">Name</label>
        <input type="text" class="guestName" name="guestName" required>
        <label for="guestEmail">Email</label>
        <input type="email" class="guestEmail" name="guestEmail" required>
        <label for="guestPhone">Phone Number</label>
        <input type="tel" class="guestPhone" name="guestPhone" required>
    `;

    guestList.appendChild(guestDiv);
}

function addBudgetItem() {
    const budgetList = document.getElementById('budgetList');
    const budgetDiv = document.createElement('div');
    budgetDiv.classList.add('budgetItem');

    budgetDiv.innerHTML = `
        <label for="budgetItem">Item</label>
        <input type="text" class="budgetItemName" name="budgetItem" required>
        <label for="budgetAmount">Amount</label>
        <input type="number" step="0.01" class="budgetAmount" name="budgetAmount" required>
    `;

    budgetList.appendChild(budgetDiv);
}

function addVendor() {
    const vendorList = document.getElementById('vendorList');
    const vendorDiv = document.createElement('div');
    vendorDiv.classList.add('vendor');

    vendorDiv.innerHTML = `
        <label for="vendorName">Name</label>
        <input type="text" class="vendorName" name="vendorName" required>
        <label for="vendorService">Service</label>
        <input type="text" class="vendorService" name="vendorService" required>
        <label for="vendorCost">Cost</label>
        <input type="number" step="0.01" class="vendorCost" name="vendorCost" required>
        <label for="vendorContact">Contact Info</label>
        <input type="tel" class="vendorContact" name="vendorContact" required>
    `;

    vendorList.appendChild(vendorDiv);
}
