document.addEventListener("DOMContentLoaded", function () {
    let event_item = localStorage.getItem("event");
    if (event_item) {
        let event = JSON.parse(event_item);
        displayEventDetails(event);
    }

    document.getElementById('eventForm').addEventListener('submit', function (e) {
        e.preventDefault();
        saveEvent();
    });

    document.getElementById('addGuestButton').addEventListener('click', function () {
        addGuest({ name: '', email: '', phoneNumber: '' });
    });

    document.getElementById('addBudgetButton').addEventListener('click', function () {
        addBudgetItem({ item: '', amount: '' });
    });

    document.getElementById('addVendorButton').addEventListener('click', function () {
        addVendor({ name: '', service: '', cost: '', contactInfo: '' });
    });
});

function displayEventDetails(event) {
    console.log(event.id);
    localStorage.setItem("eventid", event.id);
    document.getElementById('eventName').value = event.eventName;
    document.getElementById('description').value = event.description;
    document.getElementById('venue').value = event.venue;
    document.getElementById('eventDate').value = formatDate(event.eventDate);
    document.getElementById('eventType').value = event.eventType;

    // Populate guests
    const guestList = document.getElementById('guestList');
    guestList.innerHTML = '';
    event.guests.forEach(guest => {
        addGuest(guest);
    });

    // Populate budget items
    const budgetList = document.getElementById('budgetList');
    budgetList.innerHTML = '';
    event.budgetItems.forEach(item => {
        addBudgetItem(item);
    });

    // Populate vendors
    const vendorList = document.getElementById('vendorList');
    vendorList.innerHTML = '';
    event.vendors.forEach(vendor => {
        addVendor(vendor);
    });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function addGuest(guest) {
    const guestList = document.getElementById('guestList');
    const guestDiv = document.createElement('div');
    guestDiv.classList.add('guest');
    guestDiv.innerHTML = `
        <label for="guestName">Name</label>
        <input type="text" class="guestName" name="guestName" value="${guest.name}" required>
        <label for="guestEmail">Email</label>
        <input type="email" class="guestEmail" name="guestEmail" value="${guest.email}" required>
        <label for="guestPhone">Phone Number</label>
        <input type="tel" class="guestPhone" name="guestPhone" value="${guest.phoneNumber}" required>
    `;
    guestList.appendChild(guestDiv);
}

function addBudgetItem(item) {
    const budgetList = document.getElementById('budgetList');
    const budgetDiv = document.createElement('div');
    budgetDiv.classList.add('budgetItem');
    budgetDiv.innerHTML = `
        <label for="budgetItem">Item</label>
        <input type="text" class="budgetItemName" name="budgetItem" value="${item.item || ''}" required>
        <label for="budgetAmount">Amount</label>
        <input type="number" step="0.01" class="budgetAmount" name="budgetAmount" value="${item.amount || ''}" required>
    `;
    budgetList.appendChild(budgetDiv);
}

function addVendor(vendor) {
    const vendorList = document.getElementById('vendorList');
    const vendorDiv = document.createElement('div');
    vendorDiv.classList.add('vendor');
    vendorDiv.innerHTML = `
        <label for="vendorName">Name</label>
        <input type="text" class="vendorName" name="vendorName" value="${vendor.name || ''}" required>
        <label for="vendorService">Service</label>
        <input type="text" class="vendorService" name="vendorService" value="${vendor.service || ''}" required>
        <label for="vendorCost">Cost</label>
        <input type="number" step="0.01" class="vendorCost" name="vendorCost" value="${vendor.cost || ''}" required>
        <label for="vendorContact">Contact Info</label>
        <input type="tel" class="vendorContact" name="vendorContact" value="${vendor.contactInfo || ''}" required>
    `;
    vendorList.appendChild(vendorDiv);
}

function saveEvent() {
    let event_id = localStorage.getItem("eventid");
    const event = {
        id: event_id,
        eventName: document.getElementById('eventName').value,
        description: document.getElementById('description').value,
        venue: document.getElementById('venue').value,
        eventDate: document.getElementById('eventDate').value,
        eventType: document.getElementById('eventType').value,
        guests: Array.from(document.querySelectorAll('.guest')).map(guestDiv => ({
            name: guestDiv.querySelector('.guestName').value,
            email: guestDiv.querySelector('.guestEmail').value,
            phoneNumber: guestDiv.querySelector('.guestPhone').value
        })),
        budgetItems: Array.from(document.querySelectorAll('.budgetItem')).map(budgetDiv => ({
            item: budgetDiv.querySelector('.budgetItemName').value,
            amount: budgetDiv.querySelector('.budgetAmount').value
        })),
        vendors: Array.from(document.querySelectorAll('.vendor')).map(vendorDiv => ({
            name: vendorDiv.querySelector('.vendorName').value,
            service: vendorDiv.querySelector('.vendorService').value,
            cost: vendorDiv.querySelector('.vendorCost').value,
            contactInfo: vendorDiv.querySelector('.vendorContact').value
        }))
    };

    console.log("Event to save:", event);

    fetch('http://localhost:8080/updateEvent', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(event)
    })
        .then(response => response.json())
        .then(data => {
            window.location.href = "myevents.html"
            console.log('Success:', data);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}
