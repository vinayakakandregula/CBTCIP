


let home = document.getElementById("home");
console.log(home);

home.addEventListener("click", (e) => {
    window.location.href = "http://127.0.0.1:5500/Html/user.html"
})

let profile = document.getElementById("profile");

profile.addEventListener("click", (e) => {
    let user_id = localStorage.getItem("userid");
    console.log(user_id);
    fetch(`http://localhost:8080/fetchuserbyid?id=${user_id}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        }
    })
        .then((res) => {
            return res.json()
        })
        .then((res) => {
            localStorage.setItem("userProfile", JSON.stringify(res.data));
            window.location = "http://127.0.0.1:5500/Html/profile.html"
        })
        .catch(error => {
            console.error("Error", error);
            alert("An error occurred while fetching profile");
        });
})

function logout() {
    localStorage.clear();
    window.location.href = "index.html";
}
document.addEventListener("DOMContentLoaded", function () {
    const userId = "User_00003"; // This should ideally be dynamically set based on the logged-in user
    const eventsListContainer = document.querySelector('.events-list');

    let user_id = localStorage.getItem("userid")

    async function fetchEvents() {
        let res = await fetch(`http://localhost:8080/fetchAllEventByUserId?id=${user_id}`, {
            method: "GET",
            headers: {
                "Content-Type": "Application/json"
            }
        });
        let x = await res.json();
        console.log(res.status);
        if (res.status == 202) {
            console.log(x.data);
            displayEvents(x.data);
        } else {
            window.alert(x.message + "😒😒😒");
        }
    }

    // Function to display events on the page
    function displayEvents(events) {
        eventsListContainer.innerHTML = ''; // Clear existing events
        events.forEach(event => {
            const eventCard = document.createElement('div');
            eventCard.classList.add('event-card');
            eventCard.innerHTML = `
            <div style =text-align:start>
                <h3 >Event Name : ${event.eventName}</h3>
                <p>Description: ${event.description}</p>
                <p>Date: ${event.eventDate}</p>
                <p>Venue: ${event.venue}</p>
                <p>Type: ${event.eventType}</p>
                <h4>Guests:</h4>
                <ul>
                    ${event.guests.map(guest => `<li>Name :  ${guest.name} <br> Email : ${guest.email}<br> Phone :  ${guest.phoneNumber}</li>`).join('')}
                </ul>
                <h4>Budget Items:</h4>
                <ul>
                    ${event.budgetItems.map(item => `<li>${item.item}: $${item.amount}</li>`).join('')}
                </ul>
                <h4>Vendors:</h4>
                <ul>
                    ${event.vendors.map(vendor => `<li>${vendor.name}<br> (${vendor.service}):<br> $${vendor.cost}, <br>Contact: ${vendor.contactInfo}</li>`).join('')}
                </ul>
            </div>
            `;
            eventsListContainer.appendChild(eventCard);
        });
    }

    // Fetch and display events when the page loads
    fetchEvents();
});
