let submit = document.getElementById("submit");

submit.addEventListener("click", (e) => {
    e.preventDefault();

    let name_input = document.getElementById('name').value;
    let email_input = document.getElementById('email').value;
    let password_input = document.getElementById("password").value;
    let phone_input = document.getElementById("phoneNumber").value;

    let user = {
        firstName: name_input,
        email: email_input,
        password: password_input,
        phone: phone_input
    };

    if (name_input !== '' && email_input !== '' && password_input !== '' && phone_input !== '') {
        fetch('http://localhost:8080/saveuser', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        })
            .then(response => {
                console.log(response.status);
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error("Registration Not Successful");
                }
            })
            .then(data => {
                alert("Form Submitted Successfully");
                window.location.href = "http://127.0.0.1:5500/Html/index.html";
                console.log(data);
            })
            .catch(error => {
                console.error("Error", error);
                alert("An error occurred while submitting");
            });
    } else {
        alert("Please enter the required fields");
    }
});

let already = document.getElementById("already");
console.log(already);

already.addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "index.html";
})