package com.example.EventPlanner360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventPlanner360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
